const form  = document.getElementsByTagName('form')[0];

const email = document.getElementById('mail');
const emailError = document.querySelector('#mail + span.error');

email.addEventListener('input', function (event) {
  // Cada vez que el usuario escribe algo, verificamos si
  // los campos del formulario son válidos.

  if (email.validity.valid) {
    // En caso de que haya un mensaje de error visible, si el campo
    // es válido, eliminamos el mensaje de error.
    emailError.innerHTML = ''; // Restablece el contenido del mensaje
    emailError.className = 'error'; // Restablece el estado visual del mensaje
  } else {
    // Si todavía hay un error, muestra el error exacto
    showError();
  }
});

form.addEventListener('submit', function (event) {
  // si el campo de correo electrónico es válido, dejamos que el formulario se envíe

  if(!email.validity.valid) {
    // Si no es así, mostramos un mensaje de error apropiado
    showError();
    // Luego evitamos que se envíe el formulario cancelando el evento
    event.preventDefault();
  }
});

function showError() {
  if(email.validity.valueMissing) {
    // Si el campo está vacío
    // muestra el mensaje de error siguiente.
    emailError.textContent = 'Debe introducir una dirección de correo electrónico.';
  } else if(email.validity.typeMismatch) {
    // Si el campo no contiene una dirección de correo electrónico
    // muestra el mensaje de error siguiente.
    emailError.textContent = 'El valor introducido debe ser una dirección de correo electrónico.';
  } else if(email.validity.tooShort) {
    // Si los datos son demasiado cortos
    // muestra el mensaje de error siguiente.
    emailError.textContent = 'El correo electrónico debe tener al menos ${ email.minLength } caracteres; ha introducido ${ email.value.length }.';
  }

  // Establece el estilo apropiado
  emailError.className = 'error activo';
}

// function validarFormulario() {
//     const nombre = document.getElementById('fname').value;
    
//     nombre.addEventListener("input", function (event) {
//         if (nombre.length == 0)  {
//             nombre.setCustomValidity("No ha escrito su nombre.");
//         } else if (/^([0-9])*$/.test(nombre)) {
//             alert("El valor " + nombre + " no es una letra");
//             document.getElementById("fname").focus();
//             document.getElementById("fname").style.borderColor="red"; 
//             } else { nombre.setCustomValidity("");
//         }

//     const apellido = document.getElementById('lname').value;
    
//     apellido.addEventListener("input", function (event) {
//         if (apellido.length == 0) {
//             apellido.setCustomValidity("No ha escrito su apellido.");
//         } else if (/^([0-9])*$/.test(apellido)) {
//             alert("El valor " + apellido + " no es una letra");
//             document.getElementById("lname").focus();
//             document.getElementById("lname").style.borderColor="red";
//         } else { apellido.setCustomValidity(""); 
//         }

//     const email = document.getElementById('email').value;

//     email.addEventListener("input", function (event) {
//         if (email.validity.typeMismatch) {
//             email.setCustomValidity("No ha escrito su email.");
//         } else { email.setCustomValidity(""); 
//         }
    
//     const fono = document.getElementById('phone').value;

//     fono.addEventListener("input", function (event) {
//         if (fono.length == 0) {
//             fono.setCustomValidity("No ha escrito su número telefónico.");
//         } else if (/^([0-9])*$/.test(fono)) {
//             alert("El valor " + fono + " no es un número");
//             document.getElementById("phone").focus();
//             document.getElementById("phone").style.borderColor="red";
//         }else { fono.setCustomValidity("");
//         }
        
//     const mensaje = document.getElementById('message').value;
//         if (mensaje.length == 0) {
//             mensaje.setCustomValidity("No ha escrito su mensaje.");
//         } 
//         else { mensaje.setCustomValidity("")
//     });
    