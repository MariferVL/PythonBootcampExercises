CREATE SCHEMA `app` ;

CREATE TABLE app.basic_user 
LIKE amanel.usuarios;

INSERT app.basic_user 
SELECT *
FROM amanel.usuarios
WHERE idusuarios BETWEEN 2222 AND 2266;

ALTER TABLE `app`.`basic_user` 
ADD COLUMN `Género` VARCHAR(11) NOT NULL AFTER `FechaRegistro`,
CHANGE COLUMN `Nombre` `Nombre` VARCHAR(20) NOT NULL ,
CHANGE COLUMN `Apellido` `Apellido` VARCHAR(20) NOT NULL ,
CHANGE COLUMN `Email` `Email` VARCHAR(20) NOT NULL ,
CHANGE COLUMN `Telefono` `Telefono` VARCHAR(15) NOT NULL ,
CHANGE COLUMN `FechaRegistro` `FechaRegistro` DATE NOT NULL ;

UPDATE `app`.`basic_user` SET `Género` = 'F' WHERE (`idusuarios` = '2222');
UPDATE `app`.`basic_user` SET `Género` = 'M' WHERE (`idusuarios` = '2233');
UPDATE `app`.`basic_user` SET `Género` = 'M' WHERE (`idusuarios` = '2244');
UPDATE `app`.`basic_user` SET `Género` = 'F' WHERE (`idusuarios` = '2255');
UPDATE `app`.`basic_user` SET `Género` = 'F' WHERE (`idusuarios` = '2266');

CREATE TABLE premium_user 
LIKE basic_user;

START TRANSACTION;
INSERT INTO premium_user(idusuarios, Nombre, Apellido, Email, Telefono, FechaRegistro, Género)
SELECT *
FROM basic_user 
WHERE idusuarios BETWEEN 2255 AND 2266;
delete FROM basic_user 
WHERE idusuarios BETWEEN 2255 AND 2266;

SET autocommit = 0;

START TRANSACTION;
INSERT INTO premium_user(idusuarios, Nombre, Apellido, Email, Telefono, FechaRegistro, Género)
SELECT *
FROM basic_user 
WHERE idusuarios=2222;
delete FROM basic_user 
WHERE idusuarios=2222;

rollback 