# Formulen un programa que: 
# i. A una variable se le asigne un mensaje motivador que incluya los nombres de todos los integrantes. 
# ii. Se asegure que todos su caracteres estén en mayúscula. 
# iii. Elabore una lista con cada palabra del string. 
# iv. Cada integrante del grupo debe reconocer en qué índice está su nombre.
#  v. Indique cuántas palabras tenía el string. 
# vi. Imprima una tupla con todas las palabras del string. 
# vii. ¿Con qué función podrían obtener el mensaje por teclado al ejecutar el programa? Implementarlo!. - 

message= "Life is Impermanence. This will also change. María-Fernanda Villalobos López"
message_up= message.upper()
words= message_up.split(' ') 
print(message_up)

if "MARÍA-FERNANDA" in words:
        print(f"Tu nombre está en el índice {words.index('MARÍA-FERNANDA')}")

print(f"El mensaje contiene {len(words)} palabras.")

print(tuple(words))

print("Escriba su mensaje y dejenos su nombre o alias")
visitor_msg=input()
print(visitor_msg)