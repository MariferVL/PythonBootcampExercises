def letters_counter(text):
    return len(text)