""" DESARROLLO - Continuación del trabajo.
● Crear clases con sintaxis Python

● Actualizando lo anterior:
    + Agregar nueva clase pertinente a la aplicación que están desarrollando
        + identificar al menos 4 atributos (uno de ellos debe ser opcional). 
        + Agréguela al diagrama intuitivo que realizó en la actividad anterior.

    + Crear métodos para cada uno de los usuarios.
            + Piensen en diferentes acciones particulares que pueda ejecutar cada una de sus clases. 
            + Desarrolle 4 métodos p/clase:
                    + 2 deben incluir acciones que afecten números
                    + 2 que afecten strings. 
                    + Al menos uno de estos métodos debe aplicar los contenidos de ‘sobrecarga de métodos’.

    + Condiciones para realizar validaciones correspondientes. 
"""